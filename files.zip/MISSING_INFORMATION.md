# Information needed from you

Nothing below is published until you confirm it.

## Employer permission

1. May the product names (MiniMetro, Compass Revamp / RevMap, Joy eBike Tracking Platform, Shaktiman, Asset Management System) appear on a public profile?
1a. May the four screenshots appear publicly? I blurred vehicle numbers, device IDs, a customer account name, an email address, avatars and one freezer pin, but only your employer can approve publication. The cold chain map still shows the surrounding district, and the Shaktiman cards still show machine names with city names, so check those too.
2. May architecture be described, even in general terms? Your employer's policy decides this, not repository evidence. No diagrams, database entities, API details or screenshots of these products are included.

## Per professional product

For each product, send answers in your own words. Do not send code, endpoints, customer names or device identifiers.

1. What is the product for, in one sentence a recruiter would understand?
2. Which screens or modules did you personally build or change?
3. Which technologies did you use on it?
4. Which part of the work are you proudest of, and what was the hardest problem you solved?

Product-specific questions:

- **MiniMetro and Asset Management System:** Are they one product? If Asset Management is a module, which one?
- **Compass Revamp / RevMap:** Are Compass and RevMap separate products, or is RevMap the revamped Compass?
- **Fleet Management Platform and Compass / RevMap:** Are these the same product? The README lists them separately for now.
- **Shaktiman:** The screenshot shows a machinery fleet console covering balers, sprayers and harvesters. Is that the right description, and which screens did you build?
- **Compass and video:** The Compass screenshot has a Videos section. Is video telematics a module of Compass rather than a separate platform?
- **Cold chain map:** Which map provider does the freezer dashboard use? The Compass screenshot shows Leaflet with OpenStreetMap, but the freezer map's provider is not stated anywhere I can see.
- **Joy eBike:** Is it a standalone product? Which of these did you work on: map view, device status, dashboards?
- **Technologies:** Do you use Next.js, a state management library, a UI library such as Material UI or Tailwind CSS, a map library, Docker, GitLab, Jira or CI/CD at work? None of these appears in any repository, so none is claimed.

## Personal projects

1. **PLEXA:** Which parts did you build, frontend, backend or both? The report names you as the author but does not split the work.
2. **GBOX:** Can you add the Angular `src/` folder, and what language is `gbox backend.rar`? Without them the Angular architecture cannot be documented.
3. **Complaint Management System:** Which parts did you build within the team of three?
4. **Learnings and challenges:** Write two or three sentences for each project. The documentation pages leave these sections out because the repositories cannot show them.

## Screenshots

Screenshots of the four employer products are now included, from the images you uploaded. No personal-project repository contains a published screenshot. The PLEXA report PDF has 40 embedded images and the Complaint Management System report has 27. Tell me if you want me to review them for use. The Complaint Management System report is a team document, so check with your teammates first. PLEXA's Django folder holds uploaded test images, which I did not use.

## Contact

Send your LinkedIn URL if you want it on the profile. Say whether you want an email address or portfolio link, and give the exact value. None is invented.

## Accuracy and confidentiality review

| Check | Result |
|---|---|
| Personal project technologies | Each one traced to a dependency file, schema or source file |
| Professional technologies | Only React.js, TypeScript and REST APIs, which you stated. Unverified by me |
| Professional engineering areas | From your descriptions, not verified |
| Rising Star Award, dates and employer | From you, not verified |
| Architecture or database diagrams for employer products | None created |
| Secrets, internal URLs, customer data | None included. Database passwords in the PHP config were not copied |
| Screenshots | Four employer screenshots, with identifiers blurred, pending your employer's approval |
| Inferred database relationships | Labelled as inferred, because the dumps declare no foreign keys |
